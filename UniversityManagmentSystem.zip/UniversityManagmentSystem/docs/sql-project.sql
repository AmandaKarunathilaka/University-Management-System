-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema universitysystem
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema universitysystem
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `universitysystem` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
USE `universitysystem` ;

-- -----------------------------------------------------
-- Table `universitysystem`.`userdetails`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `universitysystem`.`userdetails` (
  `userId` INT NOT NULL AUTO_INCREMENT,
  `email` VARCHAR(25) NOT NULL,
  `username` VARCHAR(20) NOT NULL,
  `password` VARCHAR(15) NOT NULL,
  `role` VARCHAR(25) NOT NULL,
  PRIMARY KEY (`userId`))
ENGINE = InnoDB
AUTO_INCREMENT = 6
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `universitysystem`.`member`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `universitysystem`.`member` (
  `MemberId` INT NOT NULL,
  `First Name` VARCHAR(50) NULL DEFAULT NULL,
  `Last Name` VARCHAR(50) NULL DEFAULT NULL,
  `Contact No` INT NULL DEFAULT NULL,
  `User_id` INT NOT NULL,
  PRIMARY KEY (`MemberId`),
  INDEX `User_id_idx` (`User_id` ASC) VISIBLE,
  CONSTRAINT `User_id`
    FOREIGN KEY (`User_id`)
    REFERENCES `universitysystem`.`userdetails` (`userId`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `universitysystem`.`admin`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `universitysystem`.`admin` (
  `AdminId` INT NOT NULL,
  `Member_id` INT NOT NULL,
  PRIMARY KEY (`AdminId`),
  INDEX `Member_id_idx` (`Member_id` ASC) VISIBLE,
  CONSTRAINT `Member_id`
    FOREIGN KEY (`Member_id`)
    REFERENCES `universitysystem`.`member` (`MemberId`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `universitysystem`.`department`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `universitysystem`.`department` (
  `Department Id` INT NOT NULL AUTO_INCREMENT,
  `Dept Name` VARCHAR(60) NOT NULL,
  PRIMARY KEY (`Department Id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `universitysystem`.`lecturer`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `universitysystem`.`lecturer` (
  `Lecturer Id` INT NOT NULL,
  `DeptId` INT NOT NULL,
  `Memberid` INT NOT NULL,
  PRIMARY KEY (`Lecturer Id`),
  INDEX `DeptId_idx` (`DeptId` ASC) VISIBLE,
  INDEX `Memberid_idx` (`Memberid` ASC) VISIBLE,
  CONSTRAINT `DeptId`
    FOREIGN KEY (`DeptId`)
    REFERENCES `universitysystem`.`department` (`Department Id`),
  CONSTRAINT `fk_Memberid`
    FOREIGN KEY (`Memberid`)
    REFERENCES `universitysystem`.`member` (`MemberId`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `universitysystem`.`course`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `universitysystem`.`course` (
  `Course Id` VARCHAR(10) NOT NULL,
  `CourseName` VARCHAR(50) NOT NULL,
  `Credit` INT NOT NULL,
  `FacultyId` INT NOT NULL,
  `LecId` INT NOT NULL,
  PRIMARY KEY (`Course Id`),
  INDEX `LecId_idx` (`LecId` ASC) VISIBLE,
  CONSTRAINT `LecId`
    FOREIGN KEY (`LecId`)
    REFERENCES `universitysystem`.`lecturer` (`Lecturer Id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `universitysystem`.`semester`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `universitysystem`.`semester` (
  `SemId` INT NOT NULL,
  `Sem_name` VARCHAR(15) NOT NULL,
  PRIMARY KEY (`SemId`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `universitysystem`.`faculty`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `universitysystem`.`faculty` (
  `Faculty Id` INT NOT NULL,
  `Faculty Name` VARCHAR(100) NOT NULL,
  `Faculty Admin` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`Faculty Id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `universitysystem`.`student`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `universitysystem`.`student` (
  `StudentId` INT NOT NULL AUTO_INCREMENT,
  `DoB` DATETIME NOT NULL,
  `Address` VARCHAR(100) NOT NULL,
  `Guardian's Name` VARCHAR(50) NOT NULL,
  `Guardian's Mobile` INT NOT NULL,
  `FacultyId` INT NOT NULL,
  `Memberid` INT NOT NULL,
  PRIMARY KEY (`StudentId`),
  INDEX `FacultyId_idx` (`FacultyId` ASC) VISIBLE,
  INDEX `Memberid_idx` (`Memberid` ASC) VISIBLE,
  CONSTRAINT `FacultyId`
    FOREIGN KEY (`FacultyId`)
    REFERENCES `universitysystem`.`faculty` (`Faculty Id`),
  CONSTRAINT `Memberid`
    FOREIGN KEY (`Memberid`)
    REFERENCES `universitysystem`.`member` (`MemberId`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `universitysystem`.`enrollment`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `universitysystem`.`enrollment` (
  `Std_Id` INT NOT NULL,
  `Courseid` VARCHAR(10) NOT NULL,
  `Sem_Id` INT NOT NULL,
  `grade` VARCHAR(2) NOT NULL,
  INDEX `Courseid` (`Courseid` ASC) VISIBLE,
  INDEX `Std_Id_idx` (`Std_Id` ASC) VISIBLE,
  INDEX `SemId_idx` (`Sem_Id` ASC) VISIBLE,
  CONSTRAINT `Courseid`
    FOREIGN KEY (`Courseid`)
    REFERENCES `universitysystem`.`course` (`Course Id`),
  CONSTRAINT `SemId`
    FOREIGN KEY (`Sem_Id`)
    REFERENCES `universitysystem`.`semester` (`SemId`),
  CONSTRAINT `Std_Id`
    FOREIGN KEY (`Std_Id`)
    REFERENCES `universitysystem`.`student` (`StudentId`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `universitysystem`.`leavereq`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `universitysystem`.`leavereq` (
  `RequestId` INT NOT NULL,
  `leaveDate` DATETIME NOT NULL,
  `Reason` VARCHAR(100) NOT NULL,
  `Status` VARCHAR(20) NOT NULL,
  `Lec_id` INT NOT NULL,
  PRIMARY KEY (`RequestId`),
  INDEX `Lec_id_idx` (`Lec_id` ASC) VISIBLE,
  CONSTRAINT `Lec_id`
    FOREIGN KEY (`Lec_id`)
    REFERENCES `universitysystem`.`lecturer` (`Lecturer Id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `universitysystem`.`student_course`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `universitysystem`.`student_course` (
  `S_id` INT NOT NULL,
  `C_Id` VARCHAR(10) NOT NULL,
  INDEX `Std_id_idx` (`S_id` ASC) VISIBLE,
  INDEX `C_Id_idx` (`C_Id` ASC) VISIBLE,
  CONSTRAINT `C_Id`
    FOREIGN KEY (`C_Id`)
    REFERENCES `universitysystem`.`course` (`Course Id`),
  CONSTRAINT `S_id`
    FOREIGN KEY (`S_id`)
    REFERENCES `universitysystem`.`student` (`StudentId`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
