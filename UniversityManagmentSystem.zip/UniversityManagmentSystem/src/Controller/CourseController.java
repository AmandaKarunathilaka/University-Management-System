/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import Model.Course;
import Model.Faculty;

public class CourseController {
    
    public static Map<String, Integer> getFacultyMap() {
        Map<String, Integer> facultyMap = new HashMap<>();
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs =null;
        
        try {conn = DBconnection.getConnection();
            stmt = conn.createStatement();
            rs = stmt.executeQuery("SELECT FacultyId, FacultyName FROM faculty"); 
            while (rs.next()) {
                facultyMap.put(rs.getString("FacultyName"), rs.getInt("FacultyId"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally{
            try{
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            }catch (SQLException e){
                e.printStackTrace();
            }
        }
        return facultyMap;
    }
    
    //get lecturer ids to combo box
    public static List<String> getLecturerIds() {
        List<String> lecIds = new ArrayList<>();
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        
        try {conn = DBconnection.getConnection();
             stmt = conn.createStatement();
             rs = stmt.executeQuery("SELECT Lecturer_Id FROM lecturer");
            while (rs.next()) {
                lecIds.add(rs.getString("Lecturer_Id"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return lecIds;
    }
    
    // all course for combo box
    public static List<Course> getAllCourses() {
        List<Course> courseList = new ArrayList<>();
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        
        String sql = "SELECT c.Course_Id, c.CourseName, c.Credit, c.FacultyId, f.FacultyName, c.LecId " +
                     "FROM course c " +
                     "JOIN faculty f ON c.FacultyId = f.FacultyId";

        try {conn = DBconnection.getConnection();
             stmt = conn.createStatement();
             rs = stmt.executeQuery(sql); // execute SQL quries that receive data from db

            while (rs.next()) {
                String courseId = rs.getString("Course_Id");
                String courseName = rs.getString("CourseName");
                int credit = rs.getInt("Credit");
                int facultyId = rs.getInt("FacultyId");
                String facultyName = rs.getString("FacultyName");
                String lecturerId = rs.getString("LecId");
                
                // create Course object
                Course course = new Course(courseId, courseName, credit, facultyId, lecturerId);
                
                // create Faculty object and set it to the course
                Faculty faculty = new Faculty(facultyId, facultyName);
                course.setFaculty(faculty);
                
                courseList.add(course);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return courseList;
    }

    // add course details
    public static boolean insertCourse(Course course) {
        String sql = "INSERT INTO course (Course_Id, CourseName, Credit, FacultyId, LecId) VALUES (?, ?, ?, ?, ?)";
        Connection conn = null;
        PreparedStatement ps = null;
        
        try {conn = DBconnection.getConnection();
            ps = conn.prepareStatement(sql);
            
            ps.setString(1, course.getCourseId());
            ps.setString(2, course.getCourseName());
            ps.setInt(3, course.getCredit());
            ps.setInt(4, course.getFacultyId());
            ps.setString(5, course.getLecturerId());
            return ps.executeUpdate() > 0; // executeUpdate() - execute SQL commands that modify the data in db
            
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }finally {
            try {
                if (ps != null) ps.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    
    public static boolean updateCourse(Course course) {
        String sql = "UPDATE course SET CourseName = ?, Credit = ?, FacultyId = ?, LecId = ? WHERE Course_Id = ?";
        Connection conn = null;
        PreparedStatement ps = null;
        
        try {conn = DBconnection.getConnection();
            ps = conn.prepareStatement(sql);
            
            ps.setString(1, course.getCourseName());
            ps.setInt(2, course.getCredit());
            ps.setInt(3, course.getFacultyId());
            ps.setString(4, course.getLecturerId());
            ps.setString(5, course.getCourseId());
            return ps.executeUpdate() > 0;
            
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }finally {
            try {
                if (ps != null) ps.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    public static boolean deleteCourse(String courseId) {
        String sql = "DELETE FROM course WHERE Course_Id = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try {conn = DBconnection.getConnection();
             stmt = conn.prepareStatement(sql);

            stmt.setString(1, courseId);
            int rowsDeleted = stmt.executeUpdate();//modify db
            return rowsDeleted > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }finally {
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}