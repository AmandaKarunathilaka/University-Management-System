/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.Department;
import Model.Faculty;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class DepartmentController {
    
    // Static method for adding department
    public static boolean addDepartment(Department dept, String contact, String email){
        String sql = "INSERT INTO department (deptId, deptName, deptContact, deptEmail, facultyId) VALUES (?, ?, ?, ?, ?)"; 
        Connection conn = null;
        PreparedStatement stmt = null;

        try{
            conn = DBconnection.getConnection();
            stmt = conn.prepareStatement(sql);
            
            stmt.setInt(1, dept.getDeptId());
            stmt.setString(2, dept.getDeptName());
            stmt.setString(3, contact);
            stmt.setString(4, email);
            stmt.setInt(5, dept.getFaculty().getFacultyId());
            
            int rows = stmt.executeUpdate();
            return rows > 0;
            
        }catch(SQLException e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Database error: "+ e.getMessage());
            return false;
        }finally {
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    // Static method to get all departments as String arrays (for table display)
    public static List<String[]> getAllDepartments() {
        List<String[]> deptList = new ArrayList<>();
        String sql = "SELECT d.deptId, d.deptName, d.deptContact, d.deptEmail, f.facultyName " +
                     "FROM department d JOIN faculty f ON d.facultyId = f.facultyId";
        
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        try {conn = DBconnection.getConnection();
             stmt = conn.prepareStatement(sql);
             rs = stmt.executeQuery();

            while (rs.next()) {
                String[] row = {
                    String.valueOf(rs.getInt("deptId")),
                    rs.getString("deptName"),
                    rs.getString("deptContact"),
                    rs.getString("deptEmail"),
                    rs.getString("facultyName")
                };
                deptList.add(row);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to fetch departments: " + e.getMessage());
        }finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return deptList;
    }
    
    
    // Static method to get department objects
    public static List<Department> getDepartmentObjects() {
        List<Department> deptList = new ArrayList<>();
        String sql = "SELECT d.deptId, d.deptName, d.deptContact, d.deptEmail, " +
                     "f.facultyId, f.facultyName " +
                     "FROM department d JOIN faculty f ON d.facultyId = f.facultyId";
        
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        try {conn = DBconnection.getConnection();
             stmt = conn.prepareStatement(sql);
             rs = stmt.executeQuery();

            while (rs.next()) {
                // Create and populate Faculty object
                Faculty faculty = new Faculty();
                faculty.setFacultyId(rs.getInt("facultyId"));
                faculty.setFacultyName(rs.getString("facultyName"));

                // Create and populate Department object
                Department dept = new Department();
                dept.setDeptId(rs.getInt("deptId"));
                dept.setDeptName(rs.getString("deptName"));
                dept.setDeptCont(rs.getString("deptContact"));
                dept.setDeptEmail(rs.getString("deptEmail"));
                dept.setFaculty(faculty); // Set Faculty object to Department

                deptList.add(dept);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to fetch departments: " + e.getMessage());
        }finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return deptList;
    }

    
    // Static method for updating department details
    public static boolean updateDepartment(int deptId, String contact, String email){
        String sql = "UPDATE department SET deptContact=?, deptEmail=? WHERE deptId= ?";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        
        try{
            conn = DBconnection.getConnection();
            pstmt = conn.prepareStatement(sql);
        
            pstmt.setString(1, contact);
            pstmt.setString(2, email);
            pstmt.setInt(3, deptId);
            
            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
            
        }catch(SQLException ex){
            ex.printStackTrace();
            return false;
        }finally {
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    
    //delete department
    public static boolean deleteDepartment(int deptId){
        String deleteQuery = "DELETE FROM department WHERE deptId = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try {
            conn = DBconnection.getConnection();
            stmt = conn.prepareStatement(deleteQuery);

            stmt.setInt(1, deptId);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }finally {
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }   
}