/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.Faculty;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import Model.Faculty;
import java.sql.SQLException;

public class FacultyController {
    
    // add faculty
    public static boolean insertFaculty(Faculty faculty){
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try{
            conn = DBconnection.getConnection();
            String sql = "INSERT INTO faculty (facultyId, facultyName, facultyHead, facultyAdvisor) VALUES (?, ?, ?, ?)";
            stmt = conn.prepareStatement(sql);
            
            stmt.setInt(1, faculty.getFacultyId());
            stmt.setString(2, faculty.getFacultyName()); // assign or update string value
            stmt.setString(3, faculty.getFacultyHead());
            stmt.setString(4, faculty.getFacultyAdvisor());
            
            int rowInserted = stmt.executeUpdate();
            return rowInserted > 0 ;
            
        }catch(Exception e){
            e.printStackTrace();
            return false;
        }finally {
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    
    // update faculty details
    public static boolean updateFaculty(Faculty faculty){
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try{
            conn = DBconnection.getConnection();
            String sql = "UPDATE faculty SET facultyHead = ? , facultyAdvisor = ? WHERE facultyId = ? ";
            stmt = conn.prepareStatement(sql);
            
            stmt.setString(1, faculty.getFacultyHead());
            stmt.setString(2, faculty.getFacultyAdvisor());
            stmt.setInt(3, faculty.getFacultyId());
            
            int updated = stmt.executeUpdate();
            return updated > 0;
            
        }catch(Exception e){
            e.printStackTrace();
            return false;
        }finally {
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    //table viewer
    public static List<Faculty> getAllFaculties(){
        List<Faculty> list = new ArrayList<>();
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        
        try{
            conn = DBconnection.getConnection();
            String sql = "SELECT * FROM faculty";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            
            while(rs.next()){
                int id = rs.getInt("facultyId");
                String name = rs.getString("facultyName");
                String head = rs.getString("facultyHead");
                String advisor = rs.getString("facultyAdvisor");
                
                Faculty faculty = new Faculty(id, name, head, advisor);
                list.add(faculty);
            }
        }catch(Exception e){
            e.printStackTrace();
        }finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return list;
    }
    
    //delete faculty
    public static boolean deleteFaculty(int facultyId){
        String query = "DELETE FROM faculty WHERE facultyId = ?";
        Connection conn = null;
        PreparedStatement pst = null;
        
        try{conn = DBconnection.getConnection();
            pst = conn.prepareStatement(query);
            
            pst.setInt(1, facultyId);
            
            int result = pst.executeUpdate();
            return result > 0;
            
        }catch(SQLException e){
            e.printStackTrace();
            return false;
        }finally {
            try {
                if (pst != null) pst.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
