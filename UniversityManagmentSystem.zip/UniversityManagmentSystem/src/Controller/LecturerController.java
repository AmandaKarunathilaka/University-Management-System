/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Controller.DBconnection;
import Model.Account;
import Model.Lecturer;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.JOptionPane;
import java.sql.Statement;

public class LecturerController {
    Connection conn = DBconnection.getConnection();
    
    public String getDepartmentIdByName(String departmentName) {
        String deptId = null;
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        try {
            conn = DBconnection.getConnection();
            //System.out.println("Successfully");
            String query = "SELECT deptId FROM department WHERE deptName = ?";
            stmt = conn.prepareStatement(query);
            stmt.setString(1, departmentName);
            rs = stmt.executeQuery();
            if (rs.next()) {
                deptId = rs.getString("deptId");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return deptId;
    }
    
    // get all lecturers with details
    public static List<Lecturer> getAllLecturers() {
        List<Lecturer> lecturers = new ArrayList<>(); // array for lecturer objects 
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
    
        // This query is fine, it retrieves all necessary data
        String query = "SELECT l.Lecturer_Id, m.firstName, m.lastName, m.contactNo, " +
                       "u.email, u.username, u.password, u.user_id, m.MemberId, d.deptId " +
                       "FROM lecturer l " +
                       "JOIN member m ON l.Member_Id = m.MemberId " +
                       "JOIN userdetails u ON m.User_id = u.user_id " +
                       "JOIN department d ON l.DeptId = d.deptId";

        try {
            conn = DBconnection.getConnection();
            stmt = conn.prepareStatement(query);
            rs = stmt.executeQuery();

            while(rs.next()){
                //create account object
                Account acc = new Account(
                        rs.getString("email"),
                        rs.getString("username"),
                        rs.getString("password"),
                        "lecturer"
                );
                acc.setUserId(rs.getInt("user_id"));

                //creating the Lecturer object
                Lecturer lecturer = new Lecturer(
                        rs.getInt("MemberId"),
                        rs.getInt("user_id"),
                        rs.getString("firstName"),
                        rs.getString("lastName"),
                        rs.getString("contactNo"),
                        rs.getString("Lecturer_Id"),
                        rs.getInt("deptId"),
                        acc
                );
                lecturers.add(lecturer);
            }
        } catch(SQLException e) {
            e.printStackTrace();
        }
        return lecturers;
    }

    
    //Add Lecturer
    public static boolean addLecturer(Lecturer lecturer, Account account) {
        Connection conn = null;
        PreparedStatement userStmt = null;
        PreparedStatement memberStmt = null;
        PreparedStatement lecturerStmt = null;
        ResultSet userRs = null;
        ResultSet memberRs = null;
        
        try {
            conn = DBconnection.getConnection();
            conn.setAutoCommit(false);

            // Step 1: Insert into userdetails table
            String insertUser = "INSERT INTO userdetails(email, username, password, role) VALUES (?, ?, ?, ?)";
            userStmt = conn.prepareStatement(insertUser, Statement.RETURN_GENERATED_KEYS);
            userStmt.setString(1, account.getEmail());
            userStmt.setString(2, account.getUsername());
            userStmt.setString(3, account.getPassword());
            userStmt.setString(4, account.getRole());

            int userRows = userStmt.executeUpdate();
            userRs = userStmt.getGeneratedKeys();
            int userId = -1;
            if (userRs.next()) {
                userId = userRs.getInt(1);
            }

            if (userRows > 0 && userId != -1) {
                // Step 2: Insert into member table with User_id
                String insertMember = "INSERT INTO member(firstName, lastName, contactNo, User_id) VALUES (?, ?, ?, ?)";
                memberStmt = conn.prepareStatement(insertMember, Statement.RETURN_GENERATED_KEYS);//RETURN_GENERATED_KEYS - make any auto-generated keys
                memberStmt.setString(1, lecturer.getFirstName());
                memberStmt.setString(2, lecturer.getLastName());
                memberStmt.setString(3, lecturer.getContactNo());
                memberStmt.setInt(4, userId); // Add the User_id here

                int memberRows = memberStmt.executeUpdate();
                memberRs = memberStmt.getGeneratedKeys();
                int memberId = -1;
                if (memberRs.next()) {
                    memberId = memberRs.getInt(1);
                }

                if (memberRows > 0 && memberId != -1) {
                    // Step 3: Insert into lecturer table
                    String insertLecturer = "INSERT INTO lecturer(Lecturer_Id, deptId, Member_Id) VALUES (?, ?, ?)";
                    lecturerStmt = conn.prepareStatement(insertLecturer);
                    lecturerStmt.setString(1, lecturer.getLecturerId());
                    lecturerStmt.setInt(2, lecturer.getDeptId());
                    lecturerStmt.setInt(3, memberId); // Use memberId, not userId

                    int lecturerRows = lecturerStmt.executeUpdate();
                    if (lecturerRows > 0) {
                        conn.commit();
                        JOptionPane.showMessageDialog(null, "Lecturer added successfully!");
                        return true;
                    } else {
                        conn.rollback();
                        JOptionPane.showMessageDialog(null, "Failed to add lecturer!");
                        return false;
                    }
                } else {
                    conn.rollback();
                    JOptionPane.showMessageDialog(null, "Failed to add member!");
                    return false;
                }
            } else {
                conn.rollback();
                JOptionPane.showMessageDialog(null, "Failed to add user details!");
                return false;
            }

        } catch (Exception e) {
            try {
                if (conn != null) conn.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error adding lecturer: " + e.getMessage());
            return false;
        }finally {
            try {
                if (memberRs != null) memberRs.close();
                if (userRs != null) userRs.close();
                if (lecturerStmt != null) lecturerStmt.close();
                if (memberStmt != null) memberStmt.close();
                if (userStmt != null) userStmt.close();
                if (conn != null) {
                    conn.setAutoCommit(true);
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }  
    }
    
    // update lecturer
    public static boolean updateLecturer(Lecturer lecturer, Account account) {
        String updateMemberQuery = "UPDATE member SET contactNo=? WHERE MemberId=?";
        String updateLecturerQuery = "UPDATE lecturer SET DeptId=? WHERE Lecturer_Id=?";
        String updateAccountQuery = "UPDATE userdetails SET email=? WHERE user_id=?";
        
        Connection conn = null;
        PreparedStatement stmt1 = null;
        PreparedStatement stmt2 = null;
        PreparedStatement stmt3 = null;
        
        try {conn = DBconnection.getConnection();
            conn.setAutoCommit(false); // Begin transaction

            // Update member
            stmt1 = conn.prepareStatement(updateMemberQuery);
            stmt1.setString(1, lecturer.getContactNo());
            stmt1.setInt(2, lecturer.getMemberId());
            stmt1.executeUpdate();
            

            // Update lecturer
            stmt2 = conn.prepareStatement(updateLecturerQuery);
                
            stmt2.setInt(1, lecturer.getDeptId());
            stmt2.setString(2, lecturer.getLecturerId());
            stmt2.executeUpdate();


            // Update user account
            stmt3 = conn.prepareStatement(updateAccountQuery);
            stmt3.setString(1, account.getEmail());
            stmt3.setInt(2, lecturer.getUserId());
            stmt3.executeUpdate();
            
            conn.commit(); // Commit if all successful
            JOptionPane.showMessageDialog(null, "Lecturer updated successfully!");
            return true;

        }catch (SQLException e) {
            try {
                if (conn != null) conn.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error updating lecturer: " + e.getMessage());
            return false;
        }finally {
            try {
                if (stmt3 != null) stmt3.close();
                if (stmt2 != null) stmt2.close();
                if (stmt1 != null) stmt1.close();
                if (conn != null) {
                    conn.setAutoCommit(true);
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    
    //delete lecturer details
    public static boolean deleteLecturer(int userId, int memberId, String lecturerId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try {
            conn = DBconnection.getConnection();
            conn.setAutoCommit(false); // Start a transaction
            
            // 1. Delete from the child table first: 'lecturer'
            String deleteLecturerQuery = "DELETE FROM lecturer WHERE Lecturer_Id = ?";
            stmt = conn.prepareStatement(deleteLecturerQuery);
            stmt.setString(1, lecturerId);
            int lecturerRowsAffected = stmt.executeUpdate();
            stmt.close();
            //System.out.println("Lecturer record deleted successfully. Rows affected: " + lecturerRowsAffected);
            
            // 2. Then delete from the parent table: 'member'
            String deleteMemberQuery = "DELETE FROM member WHERE MemberId = ?";
            stmt = conn.prepareStatement(deleteMemberQuery);
            stmt.setInt(1, memberId);
            int memberRowsAffected = stmt.executeUpdate();
            stmt.close();
            //System.out.println("Member record deleted successfully. Rows affected: " + memberRowsAffected);
            
            // 3. Finally, delete from the 'userdetails' table
            String deleteUserQuery = "DELETE FROM userdetails WHERE user_id = ?";
            stmt = conn.prepareStatement(deleteUserQuery);
            stmt.setInt(1, userId);
            int userRowsAffected = stmt.executeUpdate();
            //System.out.println("User record deleted successfully. Rows affected: " + userRowsAffected);

            conn.commit(); // Commit the transaction if all operations were successful
            return true;

        } catch (SQLException e) {
            e.printStackTrace();
            try {
                if (conn != null) {
                    conn.rollback(); //undo the deletion if there error occur
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            return false;
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (conn != null) {
                    conn.setAutoCommit(true); // Restore default auto-commit behavior
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    //---------------------------------------------
    //---Add grades for students
    
    //Get all student IDs
    public List<String> getAllStudents(){
        List<String> studentIds = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        String query = "SELECT StudentId FROM student";
        try{
            conn = DBconnection.getConnection();
            pstmt = conn.prepareStatement(query);
            rs = pstmt.executeQuery();
            
            while(rs.next()){
                studentIds.add(rs.getString("StudentId"));
            }
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, "Error fetching student Ids: " + e.getMessage());
            e.printStackTrace();
        }finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return studentIds;
    }
    
    //get all course names
    public List<String> getAllCourseNames(){
        List<String> courseNames = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        String query = "SELECT CourseName FROM course";
        try{
            conn = DBconnection.getConnection();
            pstmt = conn.prepareStatement(query);
            rs = pstmt.executeQuery();
            
            while(rs.next()){
                courseNames.add(rs.getString("CourseName"));
            }
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, "Error fetching course names: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return courseNames;
    }
    
    // get courseid by course name
    public String getCourseIdByName(String courseName) {
        String courseId = null;
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        String query = "SELECT Course_Id FROM course WHERE CourseName = ?";
        
        try{conn = DBconnection.getConnection();
            pstmt = conn.prepareStatement(query);
            pstmt.setString(1, courseName);
            rs = pstmt.executeQuery();
            
            if (rs.next()) {
                courseId = rs.getString("Course_Id");
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error fetching course ID: " + e.getMessage());
            e.printStackTrace();
        }finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return courseId;
    }
    
    // Add grade for a student
    public static boolean addGrade(String studentId, String courseId, String grade) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        
        String query = "INSERT INTO grade (Std_Id, Course_Id, grade) VALUES (?, ?, ?)";
        try {conn = DBconnection.getConnection();
             pstmt = conn.prepareStatement(query);

            pstmt.setString(1, studentId);
            pstmt.setString(2, courseId);
            pstmt.setString(3, grade);

            int rowsInserted = pstmt.executeUpdate();
            return rowsInserted > 0;

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error adding grade: " + e.getMessage());
            e.printStackTrace();
            return false;
        }finally {
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    //get all grades with student and course names for display
    public List<Object[]> getAllGradesDisplayData() {
        List<Object[]> gradeData = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        String query = "SELECT s.StudentId, g.grade, m.firstName, m.lastName, C.Course_Id, c.CourseName " +
                        "FROM grade g " +
                        "JOIN student s ON g.Std_Id = s.StudentId " +
                        "JOIN member m ON s.M_Id = m.MemberId " +
                        "JOIN course c ON g.Course_Id = c.Course_Id";

        try {
            conn = DBconnection.getConnection();
            pstmt = conn.prepareStatement(query);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                Object[] row = { 
                    rs.getString("StudentId"),
                    rs.getString("firstName") + " " + rs.getString("lastName"), // Concatenate student's full name
                    rs.getString("CourseName"),
                    rs.getString("grade")
                };
                gradeData.add(row);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error fetching grades for display: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return gradeData;
    }
    
    // Updated method in LecturerController class
    public List<Object[]> getAllLeaveRequests() {
        List<Object[]> requestData = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        String query = "SELECT RequestId, Lec_id, leaveDate, Reason, Status FROM leavereq ORDER BY RequestId DESC";

        try {
            conn = DBconnection.getConnection();

            if (conn == null) {
                JOptionPane.showMessageDialog(null, "Database connection failed!", "Connection Error", JOptionPane.ERROR_MESSAGE);
                return requestData;
            }

            pstmt = conn.prepareStatement(query);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                Object[] row = {
                    rs.getInt("RequestId"),
                    rs.getString("Lec_id"),
                    rs.getDate("leaveDate"), // Use getDate for proper date formatting
                    rs.getString("Reason"),
                    rs.getString("Status")
                };
                requestData.add(row);
            }

        } catch (SQLException e) {
            System.err.println("SQL Error: " + e.getMessage()); // Debug line
            JOptionPane.showMessageDialog(null, "Error fetching leave requests: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        } finally {
            // Close resources properly
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return requestData;
    }
    
    
    public boolean addLeaveRequest(String lecturerId, String leaveDate, String reason, String status) {
        String query = "INSERT INTO leavereq (leaveDate, Reason, Status, Lec_id) VALUES (?, ?, ?, ?)";

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DBconnection.getConnection();

            if (conn == null) {
                JOptionPane.showMessageDialog(null, "Database connection failed!", "Connection Error", JOptionPane.ERROR_MESSAGE);
                return false;
            }

            pstmt = conn.prepareStatement(query);
            pstmt.setString(1, leaveDate);
            pstmt.setString(2, reason);
            pstmt.setString(3, status);
            pstmt.setString(4, lecturerId);

            int rowsInserted = pstmt.executeUpdate();

            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(null, "Leave request submitted successfully!");
                return true;
            } else {
                return false;
            }

        } catch (SQLException e) {
            System.err.println("SQL Error: " + e.getMessage()); // Debug line
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error adding leave request: " + e.getMessage());
            return false;
        } finally {
            // Close resources properly
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    public boolean updateLeaveRequest(int requestId, String leaveDate,String status) {
        Connection conn = null;
        PreparedStatement stmt = null;
        
        String query = "UPDATE leavereq SET leaveDate = ?, status = ? WHERE RequestId = ?";
        
        try {conn = DBconnection.getConnection();
             stmt = conn.prepareStatement(query);
            
            stmt.setString(1, leaveDate);
            stmt.setString(2, status);
            stmt.setInt(3, requestId);

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, 
                "Database Error: " + e.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
            return false;
        }finally {
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}