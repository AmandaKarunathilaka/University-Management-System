/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.Account;
import Model.Student;
import Model.Member; 
import Model.Faculty;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import java.util.HashMap;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import java.time.LocalDate;

public class StudentController {
    private HashMap<String, Integer> facultyMap;
    
    public StudentController() {
        
        facultyMap = getFacultyMap();
    }
    
    public HashMap<String, Integer> getFacultyMap() {
        HashMap<String, Integer> facultyMap = new HashMap<>();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        String qry = "SELECT facultyId, facultyName FROM faculty";
        
        try {
            conn = DBconnection.getConnection();
            stmt = conn.prepareStatement(qry);
            rs = stmt.executeQuery();
            
            while (rs.next()) {
                facultyMap.put(rs.getString("facultyName"), rs.getInt("facultyId"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return facultyMap;
    }
    
    public String getFacultyNameById(int facultyId) {
        // Reverse the facultyMap to find the name from the ID
        for (String name : facultyMap.keySet()) {
            if (facultyMap.get(name) == facultyId) {
                return name;
            }
        }
        return "Unknown";
    }

    public int getFacultyIdByName(String facultyName) {
        if (facultyMap != null && facultyMap.containsKey(facultyName)) {
            return facultyMap.get(facultyName);
        } else {
            return -1;
        }
    }

    // --- Student Table Operations ---

    // happen after 
    public void loadStudentsToTable(DefaultTableModel model) {
        // Clear existing rows
        model.setRowCount(0);
        
        ArrayList<Student> students = getAllStudents(); // get all students from db
        for (Student student : students) {
            model.addRow(new Object[]{
                student.getStudentId(),
                student.getFirstName(),
                student.getLastName(),
                student.getDob(),
                student.getAddress(),
                student.getContactNo(),
                student.getGuardianName(),
                student.getGuardianMobile(),
                student.getFaculty().getFacultyName(),
                student.getAccount().getEmail(),
                student.getAccount().getUserId(),//hidden
                student.getMemberId()//hidden
            });
        }
    }
    
    public Account getAccountForStudent(int userId) {
    Connection conn = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;
    Account account = null;
    
    String query = "SELECT user_id, email, username, password, role FROM userdetails WHERE user_id = ?";
    
    try {
        conn = DBconnection.getConnection();
        stmt = conn.prepareStatement(query);
        stmt.setInt(1, userId);
        rs = stmt.executeQuery();
        
        if (rs.next()) {
            // Note: The password hash is not retrieved here for security,
            // but the Account constructor requires a parameter for it.
            // You can use a null or an empty string.
            account = new Account(
                rs.getInt("user_id"),
                rs.getString("email"),
                rs.getString("username"),
                rs.getString("password"), // Assuming 'password_hash' column exists
                rs.getString("role")
            );
        }
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        try {
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    return account;
}
    
    
    public String[] registerStudent(Student student, int facultyId) {
        String[] credentials = new String[2];
        Connection conn = null;
        PreparedStatement userStmt = null;
        PreparedStatement mStmt = null;
        PreparedStatement stdStmt = null;
        ResultSet userKeys = null;
        ResultSet generatedKeys = null;
        
        try {
            conn = DBconnection.getConnection();
            conn.setAutoCommit(false);

            // generate credentials
            String username = student.getFirstName().toLowerCase() + student.getStudentId();
            String password = "Vtx@" + student.getFirstName().substring(0, 1).toUpperCase() + student.getStudentId();
            
            // Update the Account object with the generated credentials
            student.getAccount().setUsername(username);
            student.getAccount().setPassword(password);
            
            // Insert into userdetails
            String insertUser = "INSERT INTO userdetails (username, password, email, role) VALUES (?, ?, ?, ?)";
            userStmt = conn.prepareStatement(insertUser, Statement.RETURN_GENERATED_KEYS);
            userStmt.setString(1, username);
            userStmt.setString(2, password);
            userStmt.setString(3, student.getAccount().getEmail());
            userStmt.setString(4, "Student");

                int userRows = userStmt.executeUpdate();
                if (userRows == 0) {
                    conn.rollback();
                    JOptionPane.showMessageDialog(null, "Creating user failed, no rows affected.");
                    return null;
                }
                
                userKeys = userStmt.getGeneratedKeys();
                if (userKeys.next()) {
                    student.getAccount().setUserId(userKeys.getInt(1));
                } else {
                    conn.rollback();
                    JOptionPane.showMessageDialog(null, "Failed to get user ID.");
                    return null;
                }

                
            // Insert into member table
            String memberSql = "INSERT INTO member (firstName, lastName, contactNo, User_id) VALUES (?, ?, ?, ?)";
            mStmt = conn.prepareStatement(memberSql, Statement.RETURN_GENERATED_KEYS);
            mStmt.setString(1, student.getFirstName());
            mStmt.setString(2, student.getLastName());
            mStmt.setString(3, student.getContactNo());
            mStmt.setInt(4, student.getAccount().getUserId());

            int affectedRows = mStmt.executeUpdate();
            if (affectedRows == 0) {
                conn.rollback();
                JOptionPane.showMessageDialog(null, "Creating member failed, no rows affected.");
                return null;
            }

            generatedKeys = mStmt.getGeneratedKeys();
            if (generatedKeys.next()) {
                student.setMemberId(generatedKeys.getInt(1));
            } else {
                conn.rollback();
                JOptionPane.showMessageDialog(null, "Failed to retrieve member ID.");
                return null;
            }
             
            // Insert into student table
            String stdSql = "INSERT INTO student (StudentId, DoB, Address, Guardian_Name, Guardian_Mobile, FacultyId, M_Id) VALUES (?, ?, ?, ?, ?, ?, ?)";
            stdStmt = conn.prepareStatement(stdSql);
                    
            stdStmt.setString(1, student.getStudentId());
            stdStmt.setDate(2, java.sql.Date.valueOf(student.getDob()));
            stdStmt.setString(3, student.getAddress());
            stdStmt.setString(4, student.getGuardianName());
            stdStmt.setString(5, student.getGuardianMobile());
            stdStmt.setInt(6, facultyId);
            stdStmt.setInt(7, student.getMemberId());

            int stdRows = stdStmt.executeUpdate();
            if (stdRows == 0) {
                conn.rollback();
                JOptionPane.showMessageDialog(null, "Creating student failed, no rows affected.");
                return null;
            }
            
            conn.commit();// save all changes
            credentials[0] = username;
            credentials[1] = password;
            return credentials;

        } catch (SQLException e) {
            try { 
                if (conn != null) conn.rollback(); // cancel all changes
            } catch (SQLException ex) { 
                ex.printStackTrace(); 
            }
            e.printStackTrace();
            return null;
        } finally {
            try {
                if (generatedKeys != null) generatedKeys.close();
                if (userKeys != null) userKeys.close();
                if (stdStmt != null) stdStmt.close();
                if (mStmt != null) mStmt.close();
                if (userStmt != null) userStmt.close();
                if (conn != null) {
                    conn.setAutoCommit(true); // automatic save changes
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
    
   // next-table fun.
    public ArrayList<Student> getAllStudents() {
        ArrayList<Student> studentList = new ArrayList<>();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        String query = "SELECT s.StudentId, u.user_id, u.email, u.username, u.password, m.MemberId, m.firstName, m.lastName, m.contactNo, s.DoB, s.Address, s.Guardian_Name, s.Guardian_Mobile, f.facultyId, f.facultyName "
                     + "FROM userdetails u "
                     + "JOIN member m ON u.user_id = m.User_id "
                     + "JOIN student s ON m.MemberId = s.M_Id "
                     + "JOIN faculty f ON s.FacultyId = f.facultyId";

        try {

             conn = DBconnection.getConnection();
             stmt = conn.prepareStatement(query);
             rs = stmt.executeQuery();

            while (rs.next()) {
                // Retrieve the username and password from the ResultSet
                String username = rs.getString("username");
                String password = rs.getString("password");
                String role = "Student"; // Assuming the role is always "Student" for this query

                // create Student object with account and faculty aggregation
                Account account = new Account(rs.getInt("user_id"), rs.getString("email"), username, password, role);

                Faculty faculty = new Faculty(rs.getInt("facultyId"), rs.getString("facultyName"));

                Student student = new Student(
                    rs.getInt("MemberId"),
                    rs.getInt("user_id"),
                    rs.getString("StudentId"),
                    rs.getString("firstName"),
                    rs.getString("lastName"),
                    rs.getString("contactNo"),
                    rs.getDate("DoB").toLocalDate(),
                    rs.getString("Address"),
                    rs.getString("Guardian_Name"),
                    rs.getString("Guardian_Mobile"),
                    account,
                    faculty
                );
                studentList.add(student);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    if (conn != null) conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        return studentList;
    }
   
    public DefaultTableModel getStudentTableModel() {
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Student ID");      // 0
        model.addColumn("First Name");      // 1
        model.addColumn("Last Name");       // 2
        model.addColumn("DOB");             // 3
        model.addColumn("Address");         // 4
        model.addColumn("Contact No");      // 5
        model.addColumn("Guardian Name");   // 6
        model.addColumn("Guardian Mobile"); // 7
        model.addColumn("Faculty");         // 8
        model.addColumn("Email");           // 9
        model.addColumn("User Id");         // 10
        model.addColumn("Member Id");       // 11
        
        return model;
    }

    //update student 
    public boolean updateStudent(Student student, String email, int facultyId) {
        Connection conn = null;
        PreparedStatement stmtUserDetails = null;
        PreparedStatement stmtMember = null;
        PreparedStatement stmtStudent = null;

        try {
            conn = DBconnection.getConnection();
            conn.setAutoCommit(false); // Start transaction

            // 1. UPDATE userdetails table
            String userDetailsQuery = "UPDATE userdetails SET email = ? WHERE user_id = ?";
            stmtUserDetails = conn.prepareStatement(userDetailsQuery);
            stmtUserDetails.setString(1, email);
            stmtUserDetails.setInt(2, student.getUserId());
            stmtUserDetails.executeUpdate();

            // 2. UPDATE member table
            String memberQuery = "UPDATE member SET firstName = ?, lastName = ?, contactNo = ? WHERE MemberId = ?";
            stmtMember = conn.prepareStatement(memberQuery);
            stmtMember.setString(1, student.getFirstName());
            stmtMember.setString(2, student.getLastName());
            stmtMember.setString(3, student.getContactNo());
            stmtMember.setInt(4, student.getMemberId());
            stmtMember.executeUpdate();

            // 3. UPDATE student table
            String studentQuery = "UPDATE student SET DoB = ?, Address = ?, Guardian_Name = ?, Guardian_Mobile = ?, FacultyId = ? WHERE M_Id = ?";
            stmtStudent = conn.prepareStatement(studentQuery);
            stmtStudent.setDate(1, java.sql.Date.valueOf(student.getDob()));
            stmtStudent.setString(2, student.getAddress());
            stmtStudent.setString(3, student.getGuardianName());
            stmtStudent.setString(4, student.getGuardianMobile());
            stmtStudent.setInt(5, facultyId); // Using the facultyId passed to the method
            stmtStudent.setInt(6, student.getMemberId());
            stmtStudent.executeUpdate();

            conn.commit(); // Commit the transaction if all updates are successful
            return true;

        } catch (SQLException e) {
            if (conn != null) {
                try {
                    conn.rollback(); // Rollback on error
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            e.printStackTrace();
            return false;
        } finally {
            // Close resources
            try {
                if (stmtUserDetails != null) stmtUserDetails.close();
                if (stmtMember != null) stmtMember.close();
                if (stmtStudent != null) stmtStudent.close();
                if (conn != null) {
                    conn.setAutoCommit(true); // Reset auto-commit mode
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    // delete students
    public boolean deleteDetails(String studentId) {
        Connection conn = null;
        PreparedStatement getIdsStmt = null;
        PreparedStatement deleteStudentStmt = null;
        PreparedStatement deleteMemberStmt = null;
        PreparedStatement deleteUserStmt = null;
        ResultSet rs = null;
        
        try {
            conn = DBconnection.getConnection();
            conn.setAutoCommit(false);

            // Step 1: Get memberId and userId for the studentId
            String getIdsQuery = "SELECT s.M_Id, m.User_id FROM student s JOIN member m ON s.M_Id = m.MemberId WHERE s.StudentId = ?";
            int memberId;
            int userId;
            
            getIdsStmt = conn.prepareStatement(getIdsQuery);
            getIdsStmt.setString(1, studentId);
            
            rs = getIdsStmt.executeQuery();
            if (!rs.next()) {
                JOptionPane.showMessageDialog(null,"Student not found with StudentId: " + studentId);
                return false;
            }

            memberId = rs.getInt("M_Id");
            userId = rs.getInt("User_id");
       
            
            // Step 2: Delete from student table
            String deleteStudentSql = "DELETE FROM student WHERE StudentId = ?";
            deleteStudentStmt = conn.prepareStatement(deleteStudentSql);
            deleteStudentStmt.setString(1, studentId);
            deleteStudentStmt.executeUpdate();
            

            // Step 3: Delete from member table
            String deleteMemberSql = "DELETE FROM member WHERE MemberId = ?";
            deleteMemberStmt = conn.prepareStatement(deleteMemberSql);
            deleteMemberStmt.setInt(1, memberId);
            deleteMemberStmt.executeUpdate();
            

            // Step 4: Delete from userdetails table
            String deleteUserSql = "DELETE FROM userdetails WHERE user_id = ?";
            deleteUserStmt = conn.prepareStatement(deleteUserSql);
            deleteUserStmt.setInt(1, userId);
            deleteUserStmt.executeUpdate();
            
            // follow reverse foreign key order
            conn.commit();
            return true;

        } catch (SQLException e) {
            e.printStackTrace();
            try {
                if (conn != null) conn.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            return false;
        } finally {
            try {
                if (rs != null) rs.close();
                if (deleteUserStmt != null) deleteUserStmt.close();
                if (deleteMemberStmt != null) deleteMemberStmt.close();
                if (deleteStudentStmt != null) deleteStudentStmt.close();
                if (getIdsStmt != null) getIdsStmt.close();
                if (conn != null) {
                    conn.setAutoCommit(true);
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
    
    
    // --- Course Enrollment Methods ---
    
    // get all courses 
    public HashMap<String, String> getCourseMap() {
        
        HashMap<String, String> courseMap = new HashMap<>();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        // get CourseName > Course_Id
        String query = "SELECT Course_Id, CourseName FROM course";
        try {
            conn = DBconnection.getConnection();
            stmt = conn.prepareStatement(query);
            rs = stmt.executeQuery();
            
            while (rs.next()) {
                String CourseName = rs.getString("CourseName");
                String Course_Id = rs.getString("Course_Id");
                courseMap.put(CourseName, Course_Id);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return courseMap;
    }
    
    // check if student exists
    public boolean isValidStudent(String studentId){
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        String query = "SELECT COUNT(*) FROM student WHERE StudentId = ?";
        try {
            conn = DBconnection.getConnection();
            stmt = conn.prepareStatement(query);
            stmt.setString(1, studentId);
            rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return false;
    }
    
    // check already enrolled or not
    public boolean isAlreadyEnrolled(String studentId, String courseId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        String query = "SELECT COUNT(*) FROM enroll WHERE S_Id = ? AND C_Id = ?";
        try {
            conn = DBconnection.getConnection();
            stmt = conn.prepareStatement(query);
            stmt.setString(1, studentId);
            stmt.setString(2, courseId);
            rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return false;
    }
    
    //Gets the current number of courses a student is enrolled in
    public int getCurrentEnrollmentCount(String studentId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        String query = "SELECT COUNT(*) FROM enroll WHERE S_Id = ?";
        try {
            conn = DBconnection.getConnection();
            stmt = conn.prepareStatement(query);
            stmt.setString(1, studentId);
            rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return 0;
    }
    
    // check the student has reached the max. enrollment limit(4 courses)
    public boolean hasReachedEnrollmentLimit(String studentId) {
        int currentEnrollmentCount = getCurrentEnrollmentCount(studentId);
        return currentEnrollmentCount >= 4; 
    }
    
    // Enroll a student in a course with enrollment limit validation
    public boolean enrollStudentInCourse(String studentId, String courseId, java.sql.Date enrollmentDate) {
        Connection conn = null;
        PreparedStatement stmt = null;
    
        // Check if student has reached enrollment limit FIRST
        if (hasReachedEnrollmentLimit(studentId)) {
            return false;
        }
        
        // Check if already enrolled
        if (isAlreadyEnrolled(studentId, courseId)) {
            return false;
        }

        // Proceed with enrollment
        String query = "INSERT INTO enroll (S_Id, C_Id, Enroll_date) VALUES (?, ?, ?)";
        
        try {
            conn = DBconnection.getConnection();
            stmt = conn.prepareStatement(query); 
            stmt.setString(1, studentId);
            stmt.setString(2, courseId);
            stmt.setDate(3, enrollmentDate);
            
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Database Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }finally {
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return false;
    }
    
    
    public void loadEnrolledCoursesToTable(DefaultTableModel model, String studentId) {
        model.setRowCount(0); // Clear the table before loading
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        String query = "SELECT e.S_Id, c.CourseName, e.Enroll_date " +
                       "FROM enroll e " +
                       "JOIN course c ON e.C_Id = c.Course_Id " +
                       "WHERE e.S_Id = ? " +
                       "ORDER BY e.Enroll_date DESC";

        try {
            conn = DBconnection.getConnection(); // ADD THIS LINE - Initialize the connection
            stmt = conn.prepareStatement(query);
            stmt.setString(1, studentId);
            rs = stmt.executeQuery();
            while (rs.next()) {
                Object[] row = {
                    rs.getString("S_Id"),
                    rs.getString("CourseName"),
                    rs.getDate("Enroll_date")
                };
                model.addRow(row);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error loading enrolled courses: " + e.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    //-----------View grade report
    public List<String[]> getStudentGradesReport(String studentId) {
        List<String[]> gradeReportData = new ArrayList<>();
        Connection currentConn = null; 
        PreparedStatement pstmt = null;
        ResultSet rs = null; 

        try {
            currentConn = DBconnection.getConnection(); 
            if (currentConn == null) {
                JOptionPane.showMessageDialog(null, "Failed to connect to the database.", "Database Error", JOptionPane.ERROR_MESSAGE);
                return gradeReportData; 
            }

            // First, get student's full name and confirm student existence
            String studentNameQuery = "SELECT m.firstName, m.lastName FROM student s JOIN member m ON s.M_Id = m.MemberId WHERE s.StudentId = ?";
            pstmt = currentConn.prepareStatement(studentNameQuery); // execute query
            pstmt.setString(1, studentId);
            rs = pstmt.executeQuery(); // result of excution 

            String studentFirstName = "";
            String studentLastName = "";
            boolean studentFound = false;

            if (rs.next()) { // move cursor to next line
                studentFirstName = rs.getString("firstName");
                studentLastName = rs.getString("lastName");
                studentFound = true;
                // Add student name and ID as the first entry in the list
                gradeReportData.add(new String[]{studentFirstName + " " + studentLastName, studentId});
            }
            rs.close(); 
            pstmt.close(); 

            if (!studentFound) {
                gradeReportData.clear(); 
                return gradeReportData;
            }

            // Now, retrieve course details and grades for the student
            String gradesQuery = "SELECT c.Course_Id, c.CourseName, g.grade " +
                                 "FROM grade g " +
                                 "JOIN course c ON g.Course_Id = c.Course_Id " +
                                 "WHERE g.Std_Id = ?";
            pstmt = currentConn.prepareStatement(gradesQuery);
            pstmt.setString(1, studentId);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                String courseId = rs.getString("Course_Id");
                String courseName = rs.getString("CourseName");
                String grade = rs.getString("grade");
                gradeReportData.add(new String[]{courseId, courseName, grade});
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "SQL Error fetching student grades: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
            gradeReportData.clear(); 
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (currentConn != null) currentConn.close();
            } catch (SQLException e) {
                System.err.println("Error closing resources: " + e.getMessage());
                e.printStackTrace();
            }
        }
        return gradeReportData;
    }
}

