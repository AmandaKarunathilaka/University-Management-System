/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Controller;

import View.Welcome;

/**
 *
 * @author Amanda Karunathilaka
 */
public class UniversityManagmentSystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Welcome WelcomeFrame = new Welcome();
        WelcomeFrame.setVisible(true);
        WelcomeFrame.pack();
        WelcomeFrame.setLocationRelativeTo(null);
    }
    
}
