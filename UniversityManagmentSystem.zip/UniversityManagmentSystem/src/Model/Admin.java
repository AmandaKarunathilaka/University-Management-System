/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import Model.Account;

public class Admin extends Member {
    private String adminId;
    
    // Default constructor
    public Admin() {
        super();
    }
    
    // Constructor for a NEW Admin
    public Admin(String adminId, String fName, String lName, String contact, Account account){
        // It uses the Member constructor for new members.
        super(fName, lName, contact, account);
        this.adminId = adminId;
    }
    
    // Constructor for an EXISTING Admin loaded from a database.
    public Admin(int memberId, int userId, String adminId, String fName, String lName, String contact, Account account){
        // This 'super' call initializes the inherited attributes of an existing member.
        // It matches the Member constructor: Member(int memberId, int userId, String fName, String lName, String cont, Account acc).
        super(memberId, userId, fName, lName, contact, account);
        this.adminId = adminId;
    }
    
    public String getAdminId(){
        return adminId;
    }
    
    public void setAdminId(String a){
        this.adminId = a;
    }
}