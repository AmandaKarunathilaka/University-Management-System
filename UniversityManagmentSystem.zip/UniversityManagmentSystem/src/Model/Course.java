/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author Amanda Karunathilaka
 */
public class Course {
    private String CourseId;
    private String CourseName;
    private int Credit;
    private int facultyId;
    private String lecturerId;
    private Faculty faculty;

    public Course(String CourseId, String CourseName, int Credit, int facultyId, String lecId) {
        this.CourseId = CourseId;
        this.CourseName = CourseName;
        this.Credit = Credit;
        this.facultyId = facultyId;
        this.lecturerId = lecId;
    }

    public String getCourseId() {
        return CourseId;
    }

    public void setCourseId(String CourseId) {
        this.CourseId = CourseId;
    }

    public String getCourseName() {
        return CourseName;
    }

    public void setCourseName(String CourseName) {
        this.CourseName = CourseName;
    }

    public int getCredit() {
        return Credit;
    }

    public void setCredit(int Credit) {
        this.Credit = Credit;
    }

    public int getFacultyId() {
        return facultyId;
    }

    public void setFacultyId(int facultyId) {
        this.facultyId = facultyId;
    }

    public String getLecturerId() {
        return lecturerId;
    }

    public void setLecturerId(String lecId) {
        this.lecturerId = lecId;
    }
    
     public void setFaculty(Faculty faculty) {
        this.faculty = faculty;
    }

    public Faculty getFaculty() {
        return faculty;
    }
    
}
