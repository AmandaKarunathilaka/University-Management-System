/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

public class Department {
    private int DeptId;
    private String DeptName;
    private String DeptEmail;
    private String DeptCont;
    private Faculty faculty;

    public Department(int DeptId, String DeptName, String DeptEmail, String DeptCont, Faculty faculty) {
        this.DeptId = DeptId;
        this.DeptName = DeptName;
        this.DeptEmail = DeptEmail;
        this.DeptCont = DeptCont;
        this.faculty = faculty;
    }

    public Department(int DeptId, String DeptName, Faculty faculty) {
        this.DeptId = DeptId;
        this.DeptName = DeptName;
        this.faculty = faculty;
    }

    public Department() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    

    public int getDeptId() {
        return DeptId;
    }
    public void setDeptId(int DeptId) {
        this.DeptId = DeptId;
    }

    public String getDeptName() {
        return DeptName;
    }
    public void setDeptName(String DeptName) {
        this.DeptName = DeptName;
    }

    public String getDeptEmail() {
        return DeptEmail;
    }
    public void setDeptEmail(String DeptEmail) {
        this.DeptEmail = DeptEmail;
    }

    public String getDeptCont() {
        return DeptCont;
    }
    public void setDeptCont(String DeptCont) {
        this.DeptCont = DeptCont;
    }

    public Faculty getFaculty() {
        return faculty;
    }
    public void setFaculty(Faculty faculty) {
        this.faculty = faculty;
    }
    
    
}
