/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.util.ArrayList;
import java.util.List;

public class Faculty {
    private int facultyId;
    private String facultyName;
    private String facultyHead;
    private String facultyAdvisor;
    
    private List<Student> students;
    
    // Main constructor
    public Faculty(int facultyNo, String facultyName, String facultyHead, String facultyAdvisor) {
        this.facultyId = facultyNo;
        this.facultyName = facultyName;
        this.facultyHead = facultyHead;
        this.facultyAdvisor = facultyAdvisor;
        
        this.students = new ArrayList<>();
    }

    // Constructor needed by the StudentController's getAllStudents() method.
    // This correctly initializes the facultyId and facultyName.
    public Faculty(int facultyId, String facultyName) {
        this.facultyId = facultyId;
        this.facultyName = facultyName;
        this.students = new ArrayList<>();
    }
    
    // Default constructor
    public Faculty() {
        this.students = new ArrayList<>();
    }

    public int getFacultyId() {
        return facultyId;
    }
    public void setFacultyId(int facultyId) {
        this.facultyId = facultyId;
    }

    public String getFacultyName() {
        return facultyName;
    }
    public void setFacultyName(String facultyName) {
        this.facultyName = facultyName;
    }

    public String getFacultyHead() {
        return facultyHead;
    }
    public void setFacultyHead(String facultyHead) {
        this.facultyHead = facultyHead;
    }

    public String getFacultyAdvisor() {
        return facultyAdvisor;
    }
    public void setFacultyAdvisor(String facultyAdvisor) {
        this.facultyAdvisor = facultyAdvisor;
    }
    
    // Method to add a student to the faculty's list
    public void addStudent(Student student) {
        this.students.add(student);
    }
    
    // Method to get the list of students
    public List<Student> getStudents() {
        return students;
    }
    
    @Override
    public String toString() {
        return facultyName;
    }
}