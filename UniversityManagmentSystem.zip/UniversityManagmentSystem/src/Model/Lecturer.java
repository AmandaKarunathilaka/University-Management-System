/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import Model.Account;

public class Lecturer extends Member {
    private String lecturerId;
    private int deptId;
    
    // Default constructor
    public Lecturer() {
        super();
    }
    
    // Constructor for a NEW Lecturer
    // This constructor assumes the lecturer is being created for the first time.
    public Lecturer(String fName, String lName, String contact,
                    String lecturerId, int deptId, Account account) {
        // This 'super' call initializes the inherited attributes of the parent Member.
        // It matches the Member constructor: Member(String fName, String lName, String cont, Account acc).
        super(fName, lName, contact, account);
        
        this.lecturerId = lecturerId;
        this.deptId = deptId;
    }
    
    // Constructor for an EXISTING Lecturer loaded from a database.
    // This constructor includes memberId and userId, which are used to find the existing Member record.
    public Lecturer(int memberId, int userId, String fName, String lName, String contact,
                    String lecturerId, int deptId, Account account) {
        // This 'super' call initializes the inherited attributes of an existing member.
        // It matches the Member constructor: Member(int memberId, int userId, String fName, String lName, String cont, Account acc).
        super(memberId, userId, fName, lName, contact, account);
        
        this.lecturerId = lecturerId;
        this.deptId = deptId;
    }

    public String getLecturerId() {
        return lecturerId;
    }
    public void setLecturerId(String lecturerId) {
        this.lecturerId = lecturerId;
    }

    public int getDeptId() {
        return deptId;
    }
    public void setDeptId(int deptId) {
        this.deptId = deptId;
    }
}