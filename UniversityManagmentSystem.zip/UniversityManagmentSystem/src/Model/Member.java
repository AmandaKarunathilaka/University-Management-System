package Model;

public class Member {
    private int memberId;
    private int userId;
    private String firstName;
    private String lastName;
    private String contactNo;
    
    // This is the 'has-a' relationship. A Member 'has an' Account.
    private Account account;

    // Default Constructor
    public Member() {}

    // Constructor for a new Member with an Account
    // The Account object is passed in as a parameter
    public Member(String firstName, String lastName, String contactNo, Account account) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.contactNo = contactNo;
        
        // We initialize the Account object directly with the 'this' keyword.
        this.account = account;
    }

    // Constructor for an existing Member from the database
    public Member(int memberId, int userId, String firstName, String lastName, String contactNo, Account account) {
        this.memberId = memberId;
        this.userId = userId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.contactNo = contactNo;
        this.account = account;
    }

    public int getMemberId() {
        return memberId;
    }

    public void setMemberId(int memberId) {
        this.memberId = memberId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getContactNo() {
        return contactNo;
    }

    public void setContactNo(String contactNo) {
        this.contactNo = contactNo;
    }
    
    
    // Since the email is in the Account object, we access it through a getter
    public String getEmail() {
        return (account != null) ? account.getEmail() : null;
    }

    // The setter for email modifies the Account object's email
    public void setEmail(String email) {
        if (this.account != null) {
            this.account.setEmail(email);
        }
    }

    // Getter for the Account object itself
    public Account getAccount() {
        return account;
    }

    // Other getters and setters
    // ...
}
