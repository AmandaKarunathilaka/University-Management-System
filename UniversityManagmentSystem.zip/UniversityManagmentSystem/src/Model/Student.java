/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.time.LocalDate;

// Student inherits from Member.
public class Student extends Member {
    private String studentId;
    private LocalDate dob;
    private String address;
    private String guardianName;
    private String guardianMobile;
    
    // Aggregation: Student 'has-a' Faculty.
    private Faculty faculty;

    // Default constructor
    public Student() {
        super(); // Call the default constructor of the parent class
    }

    // Constructor for a NEW student.
    public Student(String firstName, String lastName, String contactNo, 
            LocalDate dob, String address, String guardianName, 
            String guardianMobile, String studentId, Account account, Faculty faculty) {
        
        super(firstName, lastName, contactNo, account);
        
        this.studentId = studentId;
        this.dob = dob;
        this.address = address;
        this.guardianName = guardianName;
        this.guardianMobile = guardianMobile;
        this.faculty = faculty;
    }
    
    // Corrected constructor for an EXISTING student (e.g., from a database).
    // The parameters are reordered to match the call in StudentController.getAllStudents()
    public Student(int memberId, int userId, String studentId, String firstName, String lastName, String contactNo,
                   LocalDate dob, String address, String guardianName, String guardianMobile,
                   Account account, Faculty faculty) {
        
        super(memberId, userId, firstName, lastName, contactNo, account);
        
        this.studentId = studentId;
        this.dob = dob;
        this.address = address;
        this.guardianName = guardianName;
        this.guardianMobile = guardianMobile;
        this.faculty = faculty;
    }

    // Getters and Setters for Student-specific fields.
    public String getStudentId() {
        return studentId;
    }
    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }
    
    public LocalDate getDob(){
        return dob;
    }
    public void setDob(LocalDate dob){
        this.dob = dob;
    }
    
    public String getAddress(){
        return address;
    }
    public void setAddress(String address){
        this.address = address;
    }
    
    public String getGuardianName(){
        return guardianName;
    }
    public void setGuardianName(String guardianName){
        this.guardianName = guardianName;
    }
    
    public String getGuardianMobile(){
        return guardianMobile;
    }
    public void setGuardianMobile(String guardianMobile){
        this.guardianMobile = guardianMobile;
    }
    
    public Faculty getFaculty() {
        return faculty;
    }

    public void setFaculty(Faculty faculty) {
        this.faculty = faculty;
    }
    
    public int getFacultyId() {
        return (faculty != null) ? faculty.getFacultyId() : -1;
    }
}