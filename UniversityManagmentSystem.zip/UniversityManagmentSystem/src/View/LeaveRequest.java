/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package View;

import Controller.LecturerController;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class LeaveRequest extends javax.swing.JFrame {
    private DefaultTableModel tableModel;
    private LecturerController lecturerController;
    
    boolean isUpdateMode = false;
    int selectedRequestId = -1;
    
    public LeaveRequest() {
        lecturerController = new LecturerController();
        initComponents();
        setupTableModel();
        loadLeaveRequests();
        
        
        //Clear default text and setup listeners
        reasonLeave.setText("");
        setupTableSelectionListener();
        
        // Set default selection for radio buttons
        jRadioButton2.setSelected(true);// Default to "Not Confirmed" 
        
        // ADD ACTION LISTENER FOR UPDATE BUTTON
        updateBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateBtnActionPerformed(evt);
            }
        });
    
    // ADD TOOLTIP FOR DATE FORMAT
    date.setToolTipText("Enter date in format: yyyy-MM-dd (e.g., 2024-12-25)");
    
    // SET TABLE SELECTION MODE
    rqstTable.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
    }
    
    private void setupTableModel() {
        String[] columnNames = {"Request ID", "Lecturer ID", "Leave Date", "Reason", "Status"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make cells non-editable
            }
        };
        rqstTable.setModel(tableModel);
    }
    
    private void setupTableSelectionListener() {
        rqstTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int selectedRow = rqstTable.getSelectedRow();
                if (selectedRow >= 0) {
                    loadSelectedRequestToForm(selectedRow);
                }
            }
        });
    }
    
    private void loadLeaveRequests() {
        // Clear existing data
        tableModel.setRowCount(0);
        
        try {
            List<Object[]> leaveRequests = lecturerController.getAllLeaveRequests();

            // Add data to table
            for (Object[] request : leaveRequests) {
                tableModel.addRow(request);
            }

            // FORCE TABLE TO REFRESH
            tableModel.fireTableDataChanged();
            rqstTable.repaint();
            rqstTable.revalidate();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Error loading leave requests: " + e.getMessage(), 
                "Database Error", 
                JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
    
    
    private void loadSelectedRequestToForm(int row) {
        try {
            selectedRequestId = Integer.parseInt(tableModel.getValueAt(row, 0).toString());
            lecId.setText(tableModel.getValueAt(row, 1).toString());
            date.setText(tableModel.getValueAt(row, 2).toString());
            reasonLeave.setText(tableModel.getValueAt(row, 3).toString());

            String status = tableModel.getValueAt(row, 4).toString();
            if ("Confirmed".equals(status)) {
                jRadioButton1.setSelected(true);
            } else {
                jRadioButton2.setSelected(true);
            }

            isUpdateMode = true;
            updateBtn.setText("Update Selected");
            submitBtn.setText("Submit New");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Error loading selected request: " + e.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void clearForm() {
        lecId.setText("");
        date.setText("");
        reasonLeave.setText("");
        jRadioButton2.setSelected(true); // Default to "Not Confirmed"
        isUpdateMode = false;
        selectedRequestId = -1;
        updateBtn.setText("Update");
        submitBtn.setText("Submit");
        rqstTable.clearSelection();
}

    private boolean validateDate(String dateString) {
        if (dateString == null || dateString.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Please enter a date.", 
                "Validation Error", 
                JOptionPane.ERROR_MESSAGE);
            return false;
        }

        try {
            
            java.time.format.DateTimeFormatter formatter = java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd");
            java.time.LocalDate enteredDate = java.time.LocalDate.parse(dateString.trim(), formatter);
            java.time.LocalDate currentDate = java.time.LocalDate.now();

            if (enteredDate.isBefore(currentDate)) {
                JOptionPane.showMessageDialog(this, 
                    "Cannot select a previous date. Please enter a current or future date.", 
                    "Invalid Date", 
                    JOptionPane.ERROR_MESSAGE);
                return false;
            }

            return true;

        } catch (java.time.format.DateTimeParseException e) {
            JOptionPane.showMessageDialog(this, 
                "Invalid date format. Please use yyyy-MM-dd format (e.g., 2024-12-25).", 
                "Date Format Error", 
                JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    private boolean validateForm() {
        String lecturerId = lecId.getText().trim();
        String leaveDate = date.getText().trim();
        String reason = reasonLeave.getText().trim();

        if (lecturerId.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Please enter Lecturer ID.", 
                "Validation Error", 
                JOptionPane.ERROR_MESSAGE);
            lecId.requestFocus();
            return false;
        }

        if (leaveDate.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Please enter leave date.", 
                "Validation Error", 
                JOptionPane.ERROR_MESSAGE);
            date.requestFocus();
            return false;
        }

        if (reason.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Please enter reason for leave.", 
                "Validation Error", 
                JOptionPane.ERROR_MESSAGE);
            reasonLeave.requestFocus();
            return false;
        }

        // Validate date format and future date
        return validateDate(leaveDate);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        lecId = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        date = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        reasonLeave = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        rqstTable = new javax.swing.JTable();
        submitBtn = new javax.swing.JButton();
        updateBtn = new javax.swing.JButton();
        close = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Leave Request");

        jPanel1.setBackground(new java.awt.Color(122, 174, 242));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 30)); // NOI18N
        jLabel1.setText("Request for Leave");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        jLabel2.setText("Lecturer ID");

        lecId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lecIdActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        jLabel3.setText("Date");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        jLabel4.setText("Reason");

        reasonLeave.setText("jTextField3");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        jLabel5.setText("Status");

        buttonGroup1.add(jRadioButton1);
        jRadioButton1.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        jRadioButton1.setText("Confirmed");

        buttonGroup1.add(jRadioButton2);
        jRadioButton2.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        jRadioButton2.setText("Not Confirmed");

        rqstTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "", "", "", ""
            }
        ));
        jScrollPane1.setViewportView(rqstTable);

        submitBtn.setBackground(new java.awt.Color(255, 204, 153));
        submitBtn.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        submitBtn.setText("Submit");
        submitBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitBtnActionPerformed(evt);
            }
        });

        updateBtn.setBackground(new java.awt.Color(255, 204, 153));
        updateBtn.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        updateBtn.setText("Update");
        updateBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateBtnActionPerformed(evt);
            }
        });

        close.setBackground(new java.awt.Color(255, 204, 153));
        close.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        close.setText("Close");
        close.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                closeActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(270, 270, 270)
                .addComponent(close)
                .addGap(27, 27, 27))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(101, 101, 101)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(84, 84, 84)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(reasonLeave, javax.swing.GroupLayout.PREFERRED_SIZE, 436, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(lecId, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(171, 171, 171)
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(70, 70, 70)
                                .addComponent(date, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jRadioButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(109, 109, 109)
                                .addComponent(jRadioButton2))))
                    .addComponent(jScrollPane1)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(214, 214, 214)
                        .addComponent(submitBtn)
                        .addGap(127, 127, 127)
                        .addComponent(updateBtn)))
                .addContainerGap(91, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(close))
                .addGap(52, 52, 52)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(lecId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(38, 38, 38)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(reasonLeave, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addGap(38, 38, 38)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jRadioButton1)
                    .addComponent(jRadioButton2))
                .addGap(38, 38, 38)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(updateBtn)
                    .addComponent(submitBtn))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(144, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void lecIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lecIdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_lecIdActionPerformed

    private void closeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_closeActionPerformed
        lecturerDashbaord ld = new lecturerDashbaord();
        ld.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_closeActionPerformed

    private void submitBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitBtnActionPerformed
        if (!validateForm()) {
            return;
        }

        String lecturerId = lecId.getText().trim();
        String leaveDate = date.getText().trim();
        String reason = reasonLeave.getText().trim();
        String status;
            if (jRadioButton1.isSelected()) {
                status = "Confirmed";
            } else if (jRadioButton2.isSelected()) {
                status = "Not Confirmed";
            } else {
                // This case should not be reached with a ButtonGroup, but it's good practice
                // to handle it. You could set a default or show an error message.
                JOptionPane.showMessageDialog(this, "Please select a status.", "Validation Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        
        LecturerController controller = new LecturerController();
        boolean success = controller.addLeaveRequest(lecturerId, leaveDate, reason, status);

        if (success) {
            clearForm();
            loadLeaveRequests(); // Refresh the table
        } else {
            JOptionPane.showMessageDialog(this, 
                "Failed to submit leave request. Please check if Lecturer ID exists.", 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_submitBtnActionPerformed


    private void updateBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateBtnActionPerformed
        if (!isUpdateMode || selectedRequestId == -1) {
        JOptionPane.showMessageDialog(this, 
            "Please select a request from the table to update.", 
            "No Selection", 
            JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (!validateForm()) {
            return;
        }

        // GET ALL REQUIRED FIELDS
        String leaveDate = date.getText().trim();

        // DEBUG: Print radio button states
        //System.out.println("Radio Button 1 (Confirmed) selected: " + jRadioButton1.isSelected());
        //System.out.println("Radio Button 2 (Not Confirmed) selected: " + jRadioButton2.isSelected());

        String status = jRadioButton1.isSelected() ? "Confirmed" : "Not Confirmed";
        //System.out.println("Status being sent: " + status);

        LecturerController controller = new LecturerController();
        // PASS ALL REQUIRED PARAMETERS
        boolean success = controller.updateLeaveRequest(selectedRequestId, leaveDate, status);
        
        if (success) {
            JOptionPane.showMessageDialog(this, 
                "Leave request updated successfully.", 
                "Success", 
                JOptionPane.INFORMATION_MESSAGE);

            clearForm();
            loadLeaveRequests(); // Refresh the table
        } else {
            JOptionPane.showMessageDialog(this, 
                "Failed to update leave request.", 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_updateBtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LeaveRequest.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LeaveRequest.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LeaveRequest.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LeaveRequest.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LeaveRequest().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton close;
    private javax.swing.JTextField date;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField lecId;
    private javax.swing.JTextField reasonLeave;
    private javax.swing.JTable rqstTable;
    private javax.swing.JButton submitBtn;
    private javax.swing.JButton updateBtn;
    // End of variables declaration//GEN-END:variables
}
