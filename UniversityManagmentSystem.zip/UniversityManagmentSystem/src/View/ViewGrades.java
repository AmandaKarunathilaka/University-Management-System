/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package View;

import Controller.StudentController; 
import java.util.List;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author Amanda Karunathilaka
 */
public class ViewGrades extends javax.swing.JFrame {
    private JLabel studentInfoLabel; // This will display the student's name and ID.
    private DefaultTableModel studentDetailsTableModel;
    private DefaultTableModel tableModel;
    private String loggedInStudentId;
    
    
    public ViewGrades(String studentId) {
        this.loggedInStudentId = studentId;
        
        initComponents();
        // --- Custom Initialization AFTER initComponents() ---
        setTitle("Student Grade Report");
        // No explicit setSize here, as pack() is called by initComponents and GroupLayout handles sizing.
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Recommended for child windows
        setLocationRelativeTo(null); // Center the frame on screen

        // Hide the student ID input since we're using the logged-in student
        sId.setVisible(false);//preventing the user from entering a different ID.
        jLabel2.setVisible(false);
        
        setupTableModels();
        
        
        // Automatically load the grades for the logged-in student
        loadStudentGrades(loggedInStudentId);
    }
    
    
    public ViewGrades(){
        initComponents();
        setupTableModels();
        setTitle("View Student Grades");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);//DISPOSE_ON_CLOSE - make window invisible 
        setLocationRelativeTo(null);// set the location of window relative to specified component;  null - centered on screen
    }
    
    private void setupTableModels() {
        // Setup studentDetails JTable model
        String[] studentColumnNames = {"Student ID", "Student Name"};
        studentDetailsTableModel = new DefaultTableModel(studentColumnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make cells non-editable
            }
        };
        stdDetails.setModel(studentDetailsTableModel); // Set the custom model to your stdDetails table

        // Setup courseDetails JTable model
        String[] courseColumnNames = {"Course ID", "Course Name", "Grade"};
        tableModel = new DefaultTableModel(courseColumnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make cells non-editable
            }
        };
        courseDetails.setModel(tableModel); // Set the custom model to your courseDetails table
    }
    
    
    private void loadStudentGrades(String studentIdToLoad) {
        studentDetailsTableModel.setRowCount(0); // Clear rows from student details table
        tableModel.setRowCount(0); // Clear rows from course details table

        StudentController studentController = new StudentController();
        List<String[]> gradesReport = studentController.getStudentGradesReport(studentIdToLoad);
        //List<String[]> represent list of array of string
        
        if (gradesReport.isEmpty()) {
            if (!studentController.isValidStudent(studentIdToLoad)) {
                // This case should ideally not happen if loggedInStudentId is guaranteed valid from login
                JOptionPane.showMessageDialog(ViewGrades.this, "Error: Student data not found for ID: " + studentIdToLoad + ". Please log in again.", "Student Error", JOptionPane.ERROR_MESSAGE);
            } else {
                // Display student info even if no grades are available
                studentDetailsTableModel.addRow(new Object[]{studentIdToLoad, "No Name Available"}); // Fallback
                
                if (gradesReport.size() > 0 && gradesReport.get(0) != null && gradesReport.get(0).length > 0) {
                    // Try to get name from the first row of gradesReport if it exists
                    studentDetailsTableModel.setValueAt(gradesReport.get(0)[0], 0, 1);
                }
                JOptionPane.showMessageDialog(ViewGrades.this, "No grades recorded for student ID: " + studentIdToLoad + " yet.", "No Grades", JOptionPane.INFORMATION_MESSAGE);
            }
        } else {
            // The first entry is the student's full name and ID
            String studentFullName = gradesReport.get(0)[0];
            String actualStudentId = gradesReport.get(0)[1];

            // Populate stdDetails table with student's ID and Name
            studentDetailsTableModel.addRow(new Object[]{actualStudentId, studentFullName});

            if (gradesReport.size() == 1) { // Only student info, no actual grades
                JOptionPane.showMessageDialog(ViewGrades.this, "No grades recorded for this student yet.", "No Grades", JOptionPane.INFORMATION_MESSAGE);
            } else {
                // Populate the courseDetails table with grade data
                for (int i = 1; i < gradesReport.size(); i++) { // Start from index 1 to skip student info
                    String[] gradeEntry = gradesReport.get(i);
                    // Ensure gradeEntry has at least 3 elements (Course ID, Course Name, Grade)
                    if (gradeEntry.length >= 3) {
                        tableModel.addRow(new Object[]{gradeEntry[0], gradeEntry[1], gradeEntry[2]}); // Add as Object array
                    } else {
                        System.err.println("Warning: Invalid grade data format for row " + i + ": " + String.join(", ", gradeEntry));
                    }
                }
            }
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        submitBtn = new javax.swing.JButton();
        closeBtn = new javax.swing.JButton();
        sId = new javax.swing.JTextField();
        jInternalFrame1 = new javax.swing.JInternalFrame();
        jScrollPane1 = new javax.swing.JScrollPane();
        courseDetails = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        stdDetails = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("View Grade");

        jPanel1.setBackground(new java.awt.Color(122, 174, 242));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 30)); // NOI18N
        jLabel1.setText("View Grades");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        jLabel2.setText("Student No");

        submitBtn.setBackground(new java.awt.Color(255, 204, 153));
        submitBtn.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        submitBtn.setText("Submit");
        submitBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitBtnActionPerformed(evt);
            }
        });

        closeBtn.setBackground(new java.awt.Color(255, 204, 153));
        closeBtn.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        closeBtn.setText("Close");
        closeBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                closeBtnActionPerformed(evt);
            }
        });

        sId.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N

        jInternalFrame1.setVisible(true);

        courseDetails.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3"
            }
        ));
        jScrollPane1.setViewportView(courseDetails);

        stdDetails.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Title 1", "Title 2"
            }
        ));
        jScrollPane2.setViewportView(stdDetails);

        javax.swing.GroupLayout jInternalFrame1Layout = new javax.swing.GroupLayout(jInternalFrame1.getContentPane());
        jInternalFrame1.getContentPane().setLayout(jInternalFrame1Layout);
        jInternalFrame1Layout.setHorizontalGroup(
            jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jInternalFrame1Layout.createSequentialGroup()
                .addGap(136, 136, 136)
                .addGroup(jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(141, Short.MAX_VALUE))
        );
        jInternalFrame1Layout.setVerticalGroup(
            jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jInternalFrame1Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 47, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(56, 56, 56))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(470, 470, 470)
                        .addComponent(submitBtn))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(142, 142, 142)
                        .addComponent(jInternalFrame1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(148, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(325, 325, 325)
                        .addComponent(closeBtn)
                        .addGap(40, 40, 40))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(67, 67, 67)
                        .addComponent(sId, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(321, 321, 321))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(closeBtn)
                    .addComponent(jLabel1))
                .addGap(45, 45, 45)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(sId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(18, 18, 18)
                .addComponent(jInternalFrame1)
                .addGap(42, 42, 42)
                .addComponent(submitBtn)
                .addGap(21, 21, 21))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void closeBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_closeBtnActionPerformed
        studentDashboard sd = new studentDashboard();
        sd.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_closeBtnActionPerformed

    private void submitBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitBtnActionPerformed
        // This method should only be relevant in the admin/manual lookup view.
        String studentIdToSearch = sId.getText().trim();
        if (studentIdToSearch.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a Student ID.", "Input Required", JOptionPane.WARNING_MESSAGE);
            return;
        }
        loadStudentGrades(studentIdToSearch);
    }//GEN-LAST:event_submitBtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ViewGrades.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ViewGrades.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ViewGrades.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ViewGrades.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ViewGrades().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton closeBtn;
    private javax.swing.JTable courseDetails;
    private javax.swing.JInternalFrame jInternalFrame1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField sId;
    private javax.swing.JTable stdDetails;
    private javax.swing.JButton submitBtn;
    // End of variables declaration//GEN-END:variables
}
